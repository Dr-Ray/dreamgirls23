
function addAdjacentRoom(room, roomBefore) {
 /**
  * @LATER: Write logic for creating one room after another.
  */ 
}
function sequentialRooms() {
   game.resetMap();

   /**
    * @TODO: Create one 50 x 40 room in the center.
    *        Then return TRUE.
    */ 

   drawMap(0, 0, COLS, ROWS);
  
   return false;
 
}
